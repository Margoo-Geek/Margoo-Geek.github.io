#pragma once

/*********************************
 * Ryuichi project Beta version 0.01
 * parsing.h
 * data<2020/5/24>
 * email<margoo@ryuichi.net.cn>
*********************************/

#include "ryuichi.h"
#include "global.h"

enum class PrSte{
	defVariable,
	defFunction,
	callFunction,
    errorExp
};

struct ParsingReturn {
    PrSte       ste  = PrSte::errorExp;
    std::string data = "";
    std::vector<std::string> dataVector;
};

ParsingReturn parsing(std::string command,RySizeType line,RyGload gload) {
    ParsingReturn ret;
    StringList type = RyStringOerating::SplitString(command," ");
    if (type.size() >= 1) {
        if (type[0] == "int" ||
			type[0] == "double" ||
			type[0] == "string" ||
            type[0] == "def") {
            StringList commandList = RyStringOerating::SplitString(command, " ");
            if (commandList.size() >= 2) {
                std::string def;
                def = RyStringOerating::replace_all_distinct(command, type[0], "");

                if (def.find("(") < def.find(")")) { // Declare function
                    ret.ste = PrSte::defFunction;
                    ret.data += "Type:" + type[0] + " ";
                    StringList nameList = RyStringOerating::SplitString(def,"(");
                    if (nameList.size() >= 2) {
                        nameList[0] = RyStringOerating::trim(nameList[0]);
                        nameList[1] = RyStringOerating::trim(nameList[1]);
                        ret.data += "Name:" + nameList[0] + " ";
                        if (nameList[1] == ")") {
                            ret.data += "wprama:NULL";
                            return ret;
                        }
                        else {
                            nameList[1]           = RyStringOerating::replace_all_distinct(nameList[1], ")", "");
                            StringList wparamList = RyStringOerating::SplitString(nameList[1], ",");
                            StringList getList;
							ret.data += "wprama:";
                            for (RySizeType i = 0; i < wparamList.size(); ++i) {
                                getList = RyStringOerating::SplitString(wparamList[i.data()], " ");
                                if (getList.size() >= 2) {
                                    if (getList[0] == "int" || getList[0] == "double" ||
                                        getList[0] == "float" || getList[0] == "string" ||
                                        getList[0] == "def" ||
                                        gload.Class.isClass(getList[0]) == true) {
                                        if (i != wparamList.size() - 1) {
                                            ret.data += (std::string)"T:" + getList[0] + "," + "N:" + getList[1] + ",";
                                        }
                                        else {
											ret.data += (std::string)"T:" + getList[0] + "," + "N:" + getList[1];
                                        }
                                    }
                                }
                                else {
									RySysOerating::error("Unknow type!", line, wparamList[i.data()]);
                                    exit(0);
                                }
                            }
                            ret.data = RyStringOerating::trim(ret.data);

                            return ret;
                        }
                    }
                    else {
						RySysOerating::error("Unrecognized expression!", line, command);
                    }
                }
                else {
                    if (command.find(",") == Ry_Npos_) {
                        ret.data = "";
                        ret.ste = PrSte::defVariable;
                        ret.data += "Type:" + type[0];
                        std::string wprama = "";
                        for (RySizeType typ = 1; typ < type.size(); ++typ) wprama += type[typ.data()];
                        if (wprama.find("=") == Ry_Npos_) {
                            ret.data += ",Name:" + wprama;
                            return ret;
                        }
                        else {
                            if (RyStringOerating::SplitString(wprama, "=").size() >= 2) {
                                std::string name = RyStringOerating::SplitString(wprama, "=")[0];
                                name = RyStringOerating::trim(name);
                                std::string content = RyStringOerating::SplitString(wprama, "=")[1];
                                content = RyStringOerating::trim(content);
                                ret.data += ",Name:" + name;
                                ret.data += ",Content:" + content;
                            }
                            else {
                                RySysOerating::error("Unrecognized expression!", line, command);
                                ret.ste = PrSte::errorExp;
                                return ret;
                            }
                        }
                    }
                    else {
                        std::string wprama = "";
						ret.ste = PrSte::defVariable;
						for (RySizeType typ = 1; typ < type.size(); ++typ) wprama += type[typ.data()];
                        StringList strList = RyStringOerating::SplitString(wprama, ",");

                        for (RySizeType i = 0; i < strList.size(); ++i) {
							if (RyStringOerating::SplitString(strList[i.data()], "=").size() >= 2) {
								ret.data += "Type:" + type[0];
                                std::string name = RyStringOerating::SplitString(strList[i.data()], "=")[0];
                                name = RyStringOerating::trim(name);
                                std::string content = RyStringOerating::SplitString(strList[i.data()], "=")[1];
                                content = RyStringOerating::trim(content);
                                ret.data += ",Name:" + name;
                                ret.data += ",Content:" + content;
                                ret.dataVector.push_back(ret.data);
                                ret.data = "";
                            }
                            else {
                                RySysOerating::error("Unrecognized expression!", line, command);
                                ret.ste = PrSte::errorExp;
                                return ret;
                            }
                        }

                        return ret;
                    }
                }
            }
            else {
                RySysOerating::error("Unrecognized expression!", line, command);
                ret.ste = PrSte::errorExp;
                return ret;
            }
        }
    }
    return ret;
}