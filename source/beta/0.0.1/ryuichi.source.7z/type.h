#pragma once

/*********************************
 * Ryuichi project Beta version 0.01
 * type.h
 * data<2020/5/23>
 * email<margoo@ryuichi.net.cn>
*********************************/

#include <iostream>
#include <sstream>

#include "ryuichi.h"

#define Ry_Type_Int    "int"
#define Ry_Type_Double "double"
#define Ry_Type_String "string"
#define Ry_Type_Def    "def"

struct var {
    std::string name;
    std::string content;
    std::string type;
};

static struct VarObject {
    std::vector<var> buffer;

    void push(var buf) { buffer.push_back(buf); }
    void pop() { buffer.pop_back(); }

    void clean() { buffer.clear(); }

    bool setContent(std::string name, std::string content) {
        for (RySizeType i = 0; i < buffer.size(); ++i) {
            if (buffer.at(i.data()).name == name) {
                buffer.at(i.data()).content = content;
                return true;
            }
        }

        return false;
    }

    bool isVariable(std::string name) {
		for (RySizeType i = 0; i < buffer.size(); ++i)
            if (buffer.at(i.data()).name == name) return true;

        return false;
    }
    static bool isAnyType(std::string sour) {
        if (isType(sour, "int") == true) return true;
        else if (isType(sour, "double") == true) return true;
        else if (isType(sour, "string") == true) return true;
    }

	static bool isType(std::string sour,std::string type) {
		if (Ry_Type_Int == type) {
            for (int i = 0; i < sour.size(); i++) {
                if (sour.at(i) == '-' && sour.size() > 1)  continue;
                if (sour.at(i) > '9' || sour.at(i) < '0') return false;
            }
	        return true;
        }
        else if (Ry_Type_Double == type) {
            double C_TMP;
            char   CH_TMP;
            std::stringstream sin(sour);
            if (!(sin >> C_TMP)) return false;
            if (sin >> CH_TMP)   return false;
            return true;
        }
        else if (Ry_Type_String == type) {
            if (sour.find("\"") < sour.find_last_not_of("\"") &&
                sour.find_last_of("\"") + 1 == sour.length()) 
                return true;
            return false;
        }
    }

    static bool isNum(std::string sour) {
        return isType(sour, Ry_Type_Int);
    }

    static bool isString(std::string sour) {
        return isType(sour, Ry_Type_String);
    }

    static bool isDouble(std::string sour) {
        return isType(sour, Ry_Type_Double);
    }

    RySizeType getPos(std::string name) {
		for (RySizeType i = 0; i < buffer.size(); ++i)
            if (buffer.at(i.data()).name == name) return i;
        
        return -1;
    }

    void del(std::string name) {
        if (isVariable(name) == true) buffer.erase(buffer.begin() + getPos(name).data());
    }
};
