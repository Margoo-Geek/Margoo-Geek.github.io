#pragma once

#include <fstream>

#include "ryuichi.h"
#include "parsing.h"
#include "Math.h"

bool iF(std::string wp, RyGload fGload, RyGload gload,StringList list) {
	if (wp.find("||") == Ry_Npos_ &&
		wp.find("&&") == Ry_Npos_) {
		if (wp.find(">=") != Ry_Npos_) {
			StringList rlist = RyStringOerating::SplitString(wp, ">=");
			rlist[0] = RyStringOerating::trim(rlist[0]);
			rlist[1] = RyStringOerating::trim(rlist[1]);
			if (fGload.variable.isVariable(rlist[0]) == true) {
				rlist[0] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[0]).data()).content;
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[1]).data()).content;
				}
				if (fGload.variable.isDouble(rlist[0]) == fGload.variable.isDouble(rlist[1]) &&
					fGload.variable.isNum(rlist[0]) == fGload.variable.isNum(rlist[1]) &&
					fGload.variable.isString(rlist[0]) == fGload.variable.isString(rlist[1])) {
				}
				if (fGload.variable.isString(rlist[0]) == true) {
					if (rlist[0] >= rlist[1]) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (fGload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b >= c) return true;
					else return false;
				}
				else if (fGload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b >= c) return true;
					else return false;
				}
			}
			else {
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[0] = gload.variable.buffer.at(gload.variable.getPos(rlist[0]).data()).content;
				}
				if (gload.variable.isVariable(rlist[1]) == true) {
					rlist[1] = gload.variable.buffer.at(gload.variable.getPos(rlist[1]).data()).content;
				}
				if (gload.variable.isDouble(rlist[0]) == gload.variable.isDouble(rlist[1]) &&
					gload.variable.isNum(rlist[0]) == gload.variable.isNum(rlist[1]) &&
					gload.variable.isString(rlist[0]) == gload.variable.isString(rlist[1])) {
				}
				if (gload.variable.isString(rlist[0]) == true) {
					if (rlist[0] >= rlist[1]) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (gload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b >= c) return true;
					else return false;
				}
				else if (gload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b >= c) return true;
					else return false;
				}
			}
		}
		else if (wp.find("<=") != Ry_Npos_) {
			StringList rlist = RyStringOerating::SplitString(wp, "<=");
			rlist[0] = RyStringOerating::trim(rlist[0]);
			rlist[1] = RyStringOerating::trim(rlist[1]);
			if (fGload.variable.isVariable(rlist[0]) == true) {
				rlist[0] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[0]).data()).content;
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[1]).data()).content;
				}
				if (fGload.variable.isDouble(rlist[0]) == fGload.variable.isDouble(rlist[1]) &&
					fGload.variable.isNum(rlist[0]) == fGload.variable.isNum(rlist[1]) &&
					fGload.variable.isString(rlist[0]) == fGload.variable.isString(rlist[1])) {
				}
				if (fGload.variable.isString(rlist[0]) == true) {
					if (rlist[0] >= rlist[1]) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (fGload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b <= c) return true;
					else return false;
				}
				else if (fGload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b <= c) return true;
					else return false;
				}
			}
			else {
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[0] = gload.variable.buffer.at(gload.variable.getPos(rlist[0]).data()).content;
				}
				if (gload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = gload.variable.buffer.at(gload.variable.getPos(rlist[1]).data()).content;
				}
				if (gload.variable.isDouble(rlist[0]) == gload.variable.isDouble(rlist[1]) &&
					gload.variable.isNum(rlist[0]) == gload.variable.isNum(rlist[1]) &&
					gload.variable.isString(rlist[0]) == gload.variable.isString(rlist[1])) {
				}
				if (gload.variable.isString(rlist[0]) == true) {
					if (rlist[0] >= rlist[1]) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (gload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b <= c) return true;
					else return false;
				}
				else if (gload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b <= c) return true;
					else return false;
				}
			}
		}
		else if (wp.find("<") != Ry_Npos_) {
			StringList rlist = RyStringOerating::SplitString(wp, "<");
			rlist[0] = RyStringOerating::trim(rlist[0]);
			rlist[1] = RyStringOerating::trim(rlist[1]);
			if (fGload.variable.isVariable(rlist[0]) == true) {
				rlist[0] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[0]).data()).content;
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[1]).data()).content;
				}
				if (fGload.variable.isDouble(rlist[0]) == fGload.variable.isDouble(rlist[1]) &&
					fGload.variable.isNum(rlist[0]) == fGload.variable.isNum(rlist[1]) &&
					fGload.variable.isString(rlist[0]) == fGload.variable.isString(rlist[1])) {
				}
				if (fGload.variable.isString(rlist[0]) == true) {
					if (rlist[0].size() < rlist[1].size()) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (fGload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b < c) return true;
					else return false;
				}
				else if (fGload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b < c) return true;
					else return false;
				}
			}
			else {
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[0] = gload.variable.buffer.at(gload.variable.getPos(rlist[0]).data()).content;
				}
				if (gload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = gload.variable.buffer.at(gload.variable.getPos(rlist[1]).data()).content;
				}
				if (gload.variable.isDouble(rlist[0]) == gload.variable.isDouble(rlist[1]) &&
					gload.variable.isNum(rlist[0]) == gload.variable.isNum(rlist[1]) &&
					gload.variable.isString(rlist[0]) == gload.variable.isString(rlist[1])) {
				}
				if (gload.variable.isString(rlist[0]) == true) {
					if (rlist[0].size() < rlist[1].size()) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (gload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b < c) return true;
					else return false;
				}
				else if (gload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b < c) return true;
					else return false;
				}
			}
		}
		else if (wp.find(">") != Ry_Npos_) {
			StringList rlist = RyStringOerating::SplitString(wp, ">");
			rlist[0] = RyStringOerating::trim(rlist[0]);
			rlist[1] = RyStringOerating::trim(rlist[1]);
			if (fGload.variable.isVariable(rlist[0]) == true) {
				rlist[0] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[0]).data()).content;
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[1]).data()).content;
				}
				if (fGload.variable.isDouble(rlist[0]) == fGload.variable.isDouble(rlist[1]) &&
					fGload.variable.isNum(rlist[0]) == fGload.variable.isNum(rlist[1]) &&
					fGload.variable.isString(rlist[0]) == fGload.variable.isString(rlist[1])) {
				}
				if (fGload.variable.isString(rlist[0]) == true) {
					if (rlist[0].size() > rlist[1].size()) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (fGload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b > c) return true;
					else return false;
				}
				else if (fGload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b > c) return true;
					else return false;
				}
			}
			else {
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[0] = gload.variable.buffer.at(gload.variable.getPos(rlist[0]).data()).content;
				}
				if (gload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = gload.variable.buffer.at(gload.variable.getPos(rlist[1]).data()).content;
				}
				if (gload.variable.isDouble(rlist[0]) == gload.variable.isDouble(rlist[1]) &&
					gload.variable.isNum(rlist[0]) == gload.variable.isNum(rlist[1]) &&
					gload.variable.isString(rlist[0]) == gload.variable.isString(rlist[1])) {
				}
				if (gload.variable.isString(rlist[0]) == true) {
					if (rlist[0].size() > rlist[1].size()) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (gload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b > c) return true;
					else return false;
				}
				else if (gload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b > c) return true;
					else return false;
				}
			}
		}
		else if (wp.find("==") != Ry_Npos_) {
			StringList rlist = RyStringOerating::SplitString(wp, "==");
			rlist[0] = RyStringOerating::trim(rlist[0]);
			rlist[1] = RyStringOerating::trim(rlist[1]);
			if (fGload.variable.isVariable(rlist[0]) == true) {
				rlist[0] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[0]).data()).content;
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = fGload.variable.buffer.at(fGload.variable.getPos(rlist[1]).data()).content;
				}
				if (fGload.variable.isDouble(rlist[0]) == fGload.variable.isDouble(rlist[1]) &&
					fGload.variable.isNum(rlist[0]) == fGload.variable.isNum(rlist[1]) &&
					fGload.variable.isString(rlist[0]) == fGload.variable.isString(rlist[1])) {
				}
				if (fGload.variable.isString(rlist[0]) == true) {
					if (rlist[0].size() == rlist[1].size()) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (fGload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b == c) return true;
					else return false;
				}
				else if (fGload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b == c) return true;
					else return false;
				}
			}
			else {
				if (fGload.variable.isVariable(rlist[0]) == true) {
					rlist[0] = gload.variable.buffer.at(gload.variable.getPos(rlist[0]).data()).content;
				}
				if (gload.variable.isVariable(rlist[0]) == true) {
					rlist[1] = gload.variable.buffer.at(gload.variable.getPos(rlist[1]).data()).content;
				}
				if (gload.variable.isDouble(rlist[0]) == gload.variable.isDouble(rlist[1]) &&
					gload.variable.isNum(rlist[0]) == gload.variable.isNum(rlist[1]) &&
					gload.variable.isString(rlist[0]) == gload.variable.isString(rlist[1])) {
				}
				if (gload.variable.isString(rlist[0]) == true) {
					if (rlist[0].size() == rlist[1].size()) {
						return true;
					}
					else {
						return false;
					}
				}
				else if (gload.variable.isNum(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					int b = std::stoi(rlist[0]), c = std::stoi(rlist[1]);
					if (b == c) return true;
					else return false;
				}
				else if (gload.variable.isDouble(rlist[0]) == true) {
					std::fstream i(rlist[0]), k(rlist[1]);
					double b, c;
					i >> b;
					k >> c;
					if (b == c) return true;
					else return false;
				}
			}
		}

	}
}

static RyGload* runFunction(RyGload gload,std::string name,RyGload* wprama_ = NULL) {
	if (gload.function.getPos(name).data() != -1) {
		RyGload fGload;
		function fn = gload.function.buffer.at(gload.function.getPos(name).data());
		StringList list;
		std::string wp;
		ParsingReturn ret;
		for (RySizeType i = 0; i < fn.command.size(); ++i) {
			list = RyStringOerating::SplitString(fn.command[i.data()]," ");
			ret = parsing(fn.command[i.data()], -1, fGload);
			if (ret.ste == PrSte::defVariable) {
				if (ret.dataVector.size() == 0) {
					var v;
					v.type = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.data, ",")[0], "Type:", "");
					v.name = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.data, ",")[1], "Name:", "");
					if (RyStringOerating::SplitString(ret.data, ",").size() >= 3) {
						v.content = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.data, ",")[2], "Content:", "");
						if (v.type == "string") v.content = RyStringOerating::reduction(v.content);
						if (v.type == "int") {
							for (RySizeType i = 0; i < gload.variable.buffer.size(); ++i)
								v.content = RyStringOerating::replace_all_distinct(v.content, gload.variable.buffer.at(i.data()).name, gload.variable.buffer.at(i.data()).content);
							for (RySizeType i = 0; i < fGload.variable.buffer.size(); ++i)
								v.content = RyStringOerating::replace_all_distinct(v.content, fGload.variable.buffer.at(i.data()).name, fGload.variable.buffer.at(i.data()).content);
							int cont = static_cast<int>(Eval(v.content));
							v.content = std::to_string(cont);
							v.content = RyStringOerating::trimOf(v.content,"0");
						}
						if (v.type == "double") {
							for (RySizeType i = 0; i < gload.variable.buffer.size(); ++i)
								v.content = RyStringOerating::replace_all_distinct(v.content, gload.variable.buffer.at(i.data()).name, gload.variable.buffer.at(i.data()).content);
							for (RySizeType i = 0; i < fGload.variable.buffer.size(); ++i)
								v.content = RyStringOerating::replace_all_distinct(v.content, fGload.variable.buffer.at(i.data()).name, fGload.variable.buffer.at(i.data()).content);
							double cont = Eval(v.content);
							v.content = std::to_string(cont);
							v.content = RyStringOerating::trimOf(v.content,"0");
							if (v.content.find(".") == v.content.size() - 1) {
									v.content = RyStringOerating::trimOf(v.content, ".");
							}
						}
					}
					else {
						v.content = "";
					}
					fGload.variable.push(v);
				}
				else {
					for (RySizeType i = 0; i < ret.dataVector.size(); ++i) {
						var v;
						v.type = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.dataVector[i.data()], ",")[0], "Type:", "");
						v.name = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.dataVector[i.data()], ",")[1], "Name:", "");
						if (RyStringOerating::SplitString(ret.dataVector[i.data()], ",").size() >= 3) {
							v.content = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.dataVector[i.data()], ",")[2], "Content:", "");
							if (v.type == "string")
								v.content = RyStringOerating::reduction(v.content);
							if (v.type == "int") {
								for (RySizeType i = 0; i < gload.variable.buffer.size(); ++i)
									v.content = RyStringOerating::replace_all_distinct(v.content, gload.variable.buffer.at(i.data()).name,gload.variable.buffer.at(i.data()).content);
								for (RySizeType i = 0; i < fGload.variable.buffer.size(); ++i)
									v.content = RyStringOerating::replace_all_distinct(v.content, fGload.variable.buffer.at(i.data()).name,fGload.variable.buffer.at(i.data()).content);
								int cont = static_cast<int>(Eval(v.content));
								v.content = std::to_string(cont);
								v.content = RyStringOerating::trimOf(v.content,"0");
							}
							if (v.type == "double") {
								for (RySizeType i = 0; i < gload.variable.buffer.size(); ++i)
									v.content = RyStringOerating::replace_all_distinct(v.content, gload.variable.buffer.at(i.data()).name,gload.variable.buffer.at(i.data()).content);
								for (RySizeType i = 0; i < fGload.variable.buffer.size(); ++i)
									v.content = RyStringOerating::replace_all_distinct(v.content, fGload.variable.buffer.at(i.data()).name,fGload.variable.buffer.at(i.data()).content);
								double cont = Eval(v.content);
								v.content = std::to_string(cont);
								v.content = RyStringOerating::trimOf(v.content,"0");
								if (v.content.find(".") == v.content.size() - 1) {
									v.content = RyStringOerating::trimOf(v.content, ".");
								}
							}
						}
						else {
							v.content = "";
						}
						fGload.variable.push(v);
					}
				}
			}
			if (list.size() >= 1) {
				for (RySizeType i = 1; i < list.size(); ++i) {
					wp += list[i.data()];
				}
				if (list[0] == "print") {
					if (wp.find(",") == Ry_Npos_ &&
						fGload.variable.isString(wp) == true) {
						wp = RyStringOerating::reduction(wp);
						std::cout << wp;
					}
					else if (gload.variable.isVariable(wp) == true &&
						wp.find(",") == Ry_Npos_) {
						if (gload.variable.getPos(wp).data() != -1) {
							std::cout << gload.variable.buffer.at(gload.variable.getPos(wp).data()).content;
						}
					}
					else if (fGload.variable.isVariable(wp) == true &&
						wp.find(",") == Ry_Npos_) {
						if (fGload.variable.getPos(wp).data() != -1) {
							std::cout << fGload.variable.buffer.at(fGload.variable.getPos(wp).data()).content;
						}
					}
					else if (wprama_ != NULL &&
						wp.find(",") == Ry_Npos_) {
						if (wprama_->variable.getPos(wp).data() != -1) {
							std::cout << wprama_->variable.buffer.at(wprama_->variable.getPos(wp).data()).content;
						}
					}
					else if (wp.find(",") != Ry_Npos_) {
						StringList outList = RyStringOerating::SplitString(wp, ",");
						for (RySizeType i = 0; i < outList.size(); ++i) {
							if (fGload.variable.isString(outList[i.data()]) == true) {
								outList[i.data()] = RyStringOerating::reduction(outList[i.data()]);
								std::cout << outList[i.data()];
							}
							else if (fGload.variable.isVariable(outList[i.data()]) == true) {
								std::cout << fGload.variable.buffer.at(fGload.variable.getPos(outList[i.data()]).data()).content;
							}
							else if (gload.variable.isVariable(outList[i.data()]) == true) {
								std::cout << gload.variable.buffer.at(gload.variable.getPos(outList[i.data()]).data()).content;
							}
							else if (wprama_ != NULL) {
								if (wprama_->variable.isVariable(outList[i.data()]) == true) {
									std::cout << wprama_->variable.buffer.at(wprama_->variable.getPos(outList[i.data()]).data()).content;
								}
							}
						}
					}
				}
				else if (list[0] == "get") {
					if (wp.find(",") == Ry_Npos_) {
						if (gload.variable.isVariable(wp) == true) {
							std::string str;
							std::cin >> str;
							gload.variable.setContent(wp, str);
						}
						else if (fGload.variable.isVariable(wp) == true) {
							std::string str;
							std::cin >> str;
							fGload.variable.setContent(wp, str);
						}
						else if (wprama_ != NULL) {
							if (wprama_->variable.isVariable(wp) == true) {
								std::string str;
								std::cin >> str;
								wprama_->variable.setContent(wp, str);
							}
						}
					}
					else {
						StringList getList = RyStringOerating::SplitString(wp, ",");
						for (RySizeType i = 0; i < getList.size(); ++i) {
							if (gload.variable.isVariable(getList[i.data()]) == true) {
								std::string str;
								std::cin >> str;
								gload.variable.setContent(getList[i.data()], str);
							}
							else if (fGload.variable.isVariable(getList[i.data()]) == true) {
								std::string str;
								std::cin >> str;
								fGload.variable.setContent(getList[i.data()], str);
							}
							else if (wprama_ != NULL) {
								if (wprama_->variable.isVariable(wp) == true) {
									std::string str;
									std::cin >> str;
									wprama_->variable.setContent(wp, str);
								}
							}
						}
					}
				}
				else if (list[0] == "if") {
					fn.command[i.data()] = RyStringOerating::replace_all_distinct(fn.command[i.data()], "{", "");
					RySizeType leve = 0;
					RyGload dGload;
					function ffn;
					ffn.functionName = "hi";
					while (true) {
						++i;
						ffn.command.push_back(fn.command[i.data()]);
						if (fn.command[i.data()].find("{") != Ry_Npos_) ++leve;
						if (fn.command[i.data()].find("}") != Ry_Npos_) {
							if (leve == 0) {
								fn.command[i.data()] = RyStringOerating::replace_all_distinct(fn.command[i.data()], "{", "");
								ffn.command.push_back(fn.command[i.data()]);
								break;
							}
							else {
								leve -= 1;
							}
						}
					}
					if (dGload.function.isFunction("hi") == true) {
						dGload.function.buffer.erase(dGload.function.buffer.begin() + dGload.function.getPos("hi").data());
					}
					dGload.function.buffer.push_back(ffn);
					for (RySizeType i = 0; i < gload.function.buffer.size(); ++i) dGload.function.buffer.push_back(gload.function.buffer[i.data()]);
					for (RySizeType i = 0; i < gload.variable.buffer.size(); ++i) dGload.variable.buffer.push_back(gload.variable.buffer[i.data()]);
					for (RySizeType i = 0; i < fGload.variable.buffer.size(); ++i) dGload.variable.buffer.push_back(fGload.variable.buffer[i.data()]);
					if (wprama_ != NULL) {
						for (RySizeType i = 0; i < wprama_->variable.buffer.size(); ++i) dGload.variable.buffer.push_back(wprama_->variable.buffer[i.data()]);
					}
					wp = RyStringOerating::replace_all_distinct(wp, "{", "");
					if (iF(wp, fGload, gload, list) == true) {
						runFunction(dGload, "hi");
					}
				}
				else if (list[0] == "exit") {
					exit(0);
				}
				else if (list[0] == "for") {
					StringList li = RyStringOerating::SplitString(wp,"to");
					for (RySizeType i = 0; i < li.size(); ++i) {
						li[i.data()] = RyStringOerating::trim(li[i.data()]);
						li[i.data()] = RyStringOerating::replace_all_distinct(li[i.data()],"{","");
						if (fGload.variable.isVariable(li[i.data()]) == true) li[i.data()] = fGload.variable.buffer[fGload.variable.getPos(li[i.data()]).data()].content;
						if (gload.variable.isVariable(li[i.data()]) == true)  li[i.data()] = gload.variable.buffer[gload.variable.getPos(li[i.data()]).data()].content;
						if (wprama_ != NULL) {
							if (wprama_->variable.isVariable(li[i.data()]) == true)  li[i.data()] = wprama_->variable.buffer[wprama_->variable.getPos(li[i.data()]).data()].content;
						}
					}
					fn.command[i.data()] = RyStringOerating::replace_all_distinct(fn.command[i.data()], "{", "");
					RySizeType leve = 0;
					RyGload dGload;
					function ffn;
					ffn.functionName = "hi";
					while (true) {
						++i;
						ffn.command.push_back(fn.command[i.data()]);
						if (fn.command[i.data()].find("{") != Ry_Npos_) ++leve;
						if (fn.command[i.data()].find("}") != Ry_Npos_) {
							if (leve == 0) {
								fn.command[i.data()] = RyStringOerating::replace_all_distinct(fn.command[i.data()], "{", "");
								ffn.command.push_back(fn.command[i.data()]);
								break;
							}
							else {
								leve -= 1;
							}
						}
					}
					if (dGload.function.isFunction("hi") == true) {
						dGload.function.buffer.erase(dGload.function.buffer.begin() + dGload.function.getPos("hi").data());
					}
					dGload.function.buffer.push_back(ffn);
					for (RySizeType i = 0; i < gload.function.buffer.size(); ++i) dGload.function.buffer.push_back(gload.function.buffer[i.data()]);
					for (RySizeType i = 0; i < gload.variable.buffer.size(); ++i) dGload.variable.buffer.push_back(gload.variable.buffer[i.data()]);
					for (RySizeType i = 0; i < fGload.variable.buffer.size(); ++i) dGload.variable.buffer.push_back(fGload.variable.buffer[i.data()]);
					wp = RyStringOerating::replace_all_distinct(wp, "{", "");
					std::stringstream be(li[0]),en(li[1]);
					int begine,end;
					be >> begine;
					en >> end;
					for (; begine < end; ++begine) {
						runFunction(dGload, "hi",wprama_);
					}
				}
				else if (fGload.function.isFunction(list[0]) == true) {
					runFunction(fGload, list[0],wprama_);
				}
				else if (gload.function.isFunction(list[0]) == true) {
					RyGload fnGload;
					RySizeType fnPos = gload.function.getPos(list[0]);
					for (RySizeType i = 0; i < gload.function.buffer[fnPos.data()].wparam.buffer.size(); ++i) {
						fnGload.variable.buffer.push_back(gload.function.buffer[fnPos.data()].wparam.buffer[i.data()]);
					}
					if (fnGload.variable.buffer.size() == 1) {
						fnGload.variable.buffer[0].content = wp;
					}
					else if (fnGload.variable.buffer.size() <= 0) {
						RySysOerating::error("Parameter is invalid", -1, list[i.data()]);
					}
					else {
						StringList wpList = RyStringOerating::SplitString(wp, ",");
						for (RySizeType i = 0; i < fnGload.variable.buffer.size(); ++i) {
							fnGload.variable.buffer[i.data()].content = wpList[i.data()];
							if (fnGload.variable.buffer[i.data()].type == "string") {
								fnGload.variable.buffer[i.data()].content = RyStringOerating::reduction(fnGload.variable.buffer[i.data()].content);
							}
						}
					}
					runFunction(gload, list[0],&fnGload);
				}
			}
			wp = "";
		}
	}
	else {
		if (name == "main") {
			RySysOerating::error("Link error: main function no found!",-1,"");
			exit(0);
		}
		else {
			RySysOerating::error("Can no found funtion: " + name,__LINE__,name,"<run.h>");
			exit(0);
		}
	}
	return NULL;
}

void doFile(std::string fileName) {
	std::fstream stream(fileName);
	std::string cmd;
	
	RyGload M_GLOAD;
	ParsingReturn ret;

	RySizeType line = 0;
	while (!stream.eof()) {
		++line;
		std::getline(stream, cmd);
		cmd = RyStringOerating::UTF8ToANSI(cmd);
		
		cmd = RyStringOerating::replace_all_distinct(cmd, "{", "");

		if (cmd != "" && cmd != "\t" && cmd != " ") {
			ret = parsing(cmd, line, M_GLOAD);
			if (ret.ste == PrSte::defFunction) {
				function fn;

				StringList fcmd;
				RySizeType leve = 0;

				StringList n = RyStringOerating::SplitString(ret.data, " ");

				while (true) {
					++line;
					std::getline(stream, cmd);
					cmd = RyStringOerating::UTF8ToANSI(cmd);
					cmd = RyStringOerating::trim(cmd);
					if (cmd.find("{") != Ry_Npos_) {
						++leve;
					}
					else if (cmd.find("}") != Ry_Npos_) {
						if (leve != 0) leve -= 1;
						else if (leve == 0) {
							break;
						}
					}
					fcmd.push_back(cmd);
				}

				fn.command = fcmd;

				StringList name;

				for (RySizeType i = 0; i < n.size(); ++i) {
					if (n[i.data()].find("Name:") == 0) {
						name = RyStringOerating::SplitString(n[i.data()], ":");
						fn.functionName = name[1];
					}
					else if (n[i.data()].find("wprama:") == 0) {
						name = RyStringOerating::SplitString(n[i.data()], ":");
						if (name[1] == "NULL") {
							var obj;
							obj.content = "";
							obj.name = "";
							obj.type = "";
							fn.wparam.buffer.push_back(obj);
						}
						else {
							name = RyStringOerating::SplitString(n[i.data()], ",");
							name[0] = RyStringOerating::replace_all_distinct(name[0], "wprama:", "");
							var obj;
							obj.content = "";
							obj.name = "";
							obj.type = "";
							for (RySizeType k = 0; k < name.size(); ++k) {
								if (name[k.data()].find("T:") != Ry_Npos_) {
									obj.type = RyStringOerating::SplitString(name[k.data()], "T:")[1];
								}
								if (name[k.data()].find("N:") != Ry_Npos_) {
									obj.name = RyStringOerating::SplitString(name[k.data()], "N:")[1];
								}
								if (obj.name != "" && obj.type != "") {
									fn.wparam.buffer.push_back(obj);
									obj.name = "";
									obj.type = "";
								}
							}
						}
					}
					else if (n[i.data()].find("Type:") == 0) {
						name = RyStringOerating::SplitString(n[i.data()], ":");
						fn.type = name[1];
					}
				}

				M_GLOAD.function.buffer.push_back(fn);
			}
			else if (ret.ste == PrSte::defVariable) {
				if (ret.dataVector.size() == 0) {
					var v;
					v.type = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.data, ",")[0], "Type:", "");
					v.name = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.data, ",")[1], "Name:", "");
					if (RyStringOerating::SplitString(ret.data, ",").size() >= 3) {
						v.content = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.data, ",")[2], "Content:", "");
						if (v.type == "string") v.content = RyStringOerating::reduction(v.content);
						if (v.type == "int") {
							for (RySizeType i = 0; i < M_GLOAD.variable.buffer.size(); ++i)
								v.content = RyStringOerating::replace_all_distinct(v.content, M_GLOAD.variable.buffer.at(i.data()).name, M_GLOAD.variable.buffer.at(i.data()).content);
							int cont = static_cast<int>(Eval(v.content));
							v.content = std::to_string(cont);
						}
						if (v.type == "double") {
							for (RySizeType i = 0; i < M_GLOAD.variable.buffer.size(); ++i)
								v.content = RyStringOerating::replace_all_distinct(v.content, M_GLOAD.variable.buffer.at(i.data()).name, M_GLOAD.variable.buffer.at(i.data()).content);
							double cont = Eval(v.content);
							v.content = std::to_string(cont);
							v.content = RyStringOerating::trimOf(v.content, "0");
							if (v.content.find(".") == v.content.size() - 1) {
								v.content = RyStringOerating::trimOf(v.content, ".");
							}
						}
					}
					else {
						v.content = "";
					}
					M_GLOAD.variable.push(v);
				}
				else {
					for (RySizeType i = 0; i < ret.dataVector.size(); ++i) {
						var v;
						v.type = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.dataVector[i.data()], ",")[0], "Type:", "");
						v.name = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.dataVector[i.data()], ",")[1], "Name:", "");
						if (RyStringOerating::SplitString(ret.dataVector[i.data()], ",").size() >= 3) {
							v.content = RyStringOerating::replace_all_distinct(RyStringOerating::SplitString(ret.dataVector[i.data()], ",")[2], "Content:", "");
							if (v.type == "string") {
								v.content = RyStringOerating::reduction(v.content);
							}
							if (v.type == "int") {
								for (RySizeType i = 0; i < M_GLOAD.variable.buffer.size(); ++i)
									v.content = RyStringOerating::replace_all_distinct(v.content, M_GLOAD.variable.buffer.at(i.data()).name, M_GLOAD.variable.buffer.at(i.data()).content);
								int cont = static_cast<int>(Eval(v.content));
								v.content = std::to_string(cont);
								v.content = RyStringOerating::trimOf(v.content, "0");
							}
							if (v.type == "double") {
								for (RySizeType i = 0; i < M_GLOAD.variable.buffer.size(); ++i)
									v.content = RyStringOerating::replace_all_distinct(v.content, M_GLOAD.variable.buffer.at(i.data()).name, M_GLOAD.variable.buffer.at(i.data()).content);
								double cont = Eval(v.content);
								v.content = std::to_string(cont);
								v.content = RyStringOerating::trimOf(v.content, "0");
								if (v.content.find(".") == v.content.size() - 1) {
									v.content = RyStringOerating::trimOf(v.content, ".");
								}
							}
						}
						else {
							v.content = "";
						}
						M_GLOAD.variable.push(v);
					}
				}
			}
		}
	}

	runFunction(M_GLOAD, "main");
}