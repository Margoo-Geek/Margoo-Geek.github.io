#pragma once
#pragma warning(disable:4091)

/*********************************
 * Ryuichi project Beta version 0.01
 * ryuichi.h
 * data<2020/5/23>
 * email<margoo@ryuichi.net.cn>
*********************************/

#include <iostream>
#include <algorithm>
#include <vector>
#include <Windows.h>

#define Ry_In_

#define RY_STRUCT_ static struct
#define Ry_Npos_ std::string::npos
#define RY_Enum_ enum class

#define StringList std::vector<std::string>

#define Ry_Find(str,fstr) str##.command.find(##fstr##)
#define Ry_Length(str) str##.command.length()
#define Ry_Get(str,num) str##.command[##num##]
#define Ry_ToString(str) str##.command

#define Ry_CreateList(type) std::vector<##type##>

#define RY_INT RySizeType

#ifdef _WIN64
struct RySizeObject {
	using RySizeTypeP = const size_t;
	using SizeType = size_t;
};
#else
struct RySizeObject {
	using RySizeTypeP = const int;
	using SizeType = int;
};
#endif

/* RySizeType - use macro compatible with x32 and x64 */

RY_STRUCT_ RySizeType {
	RySizeObject::SizeType buffer;

public:
	RySizeType(RySizeObject::SizeType  buf) {
		buffer = buf;
	}
	RySizeType() {
		buffer = 0;
	}

	const RySizeObject::SizeType data() const { return buffer; }

	RySizeType operator=(Ry_In_ RySizeObject::SizeType buf) {
		buffer = buf;
		return *this;
	}
	RySizeType operator+=(Ry_In_ RySizeObject::SizeType buf) {
		buffer += buf;
		return *this;
	}
	RySizeType operator-=(Ry_In_ RySizeObject::SizeType buf) {
		buffer -= buf;
		return *this;
	}
	RySizeType operator+(Ry_In_ RySizeObject::SizeType buf) {
		buffer = buffer + buf;
		return *this;
	}
	RySizeType operator++() {
		buffer++;
		return *this;
	}
	bool operator==(Ry_In_ RySizeObject::SizeType buf) {
		if (buffer == buf) return true;
		return false;
	}
	bool operator!=(Ry_In_ RySizeObject::SizeType buf) {
		if (buffer != buf) return true;
		return false;
	}
	bool operator<(Ry_In_ RySizeObject::SizeType buf) {
		if (buffer < buf) return true;
		return false;
	}
	bool operator<=(Ry_In_ RySizeObject::SizeType buf) {
		if (buffer <= buf) return true;
		return false;
	}
	

	RySizeType operator=(Ry_In_ RySizeType buf) {
		buffer = buf.buffer;
		return *this;
	}
	RySizeType operator+=(Ry_In_ RySizeType buf) {
		buffer += buf.buffer;
		return *this;
	}
	RySizeType operator-=(Ry_In_ RySizeType buf) {
		buffer -= buf.buffer;
		return *this;
	}
	RySizeType operator+(Ry_In_ RySizeType buf) {
		buffer = buffer + buf.buffer;
		return *this;
	}
	bool operator==(Ry_In_ RySizeType buf) {
		if (buffer == buf.buffer) return true;
		return false;
	}
	bool operator!=(Ry_In_ RySizeType buf) {
		if (buffer != buf.buffer) return true;
		return false;
	}
	bool operator<(Ry_In_ RySizeType buf) {
		if (buffer < buf.data()) return true;
		return false;
	}
	bool operator<=(Ry_In_ RySizeType buf) {
		if (buffer <= buf.data()) return true;
		return false;
	}
};

RY_STRUCT_ RyStringOerating {
	static StringList SplitString(const std::string& str, const std::string& string) {
		StringList re;
		std::string::size_type pos1, pos2;
		pos2 = str.find(string);
		pos1 = 0;
		while (std::string::npos != pos2) {
			re.push_back(str.substr(pos1, pos2 - pos1));

			pos1 = pos2 + string.size();
			pos2 = str.find(string, pos1);
		}
		if (pos1 != str.length()) re.push_back(str.substr(pos1));
		return re;
	}

	static std::string replace_all_distinct(std::string str,std::string old_value,std::string new_value)
	{
		for (std::string::size_type pos(0); pos != Ry_Npos_; pos += new_value.length()) {
			if ((pos = str.find(old_value,pos)) != Ry_Npos_) str.replace(pos,old_value.length(),new_value);
			else break;
		}
		return str;
	}

	static std::string reduction(std::string string) {
		if (string != "") {
			string = replace_all_distinct(string, "\\\"","\"");
			string = replace_all_distinct(string, "\\n", "\n");
			string = replace_all_distinct(string, "\\r", "\r");
			string = replace_all_distinct(string, "\\t", "\t");
			string = replace_all_distinct(string, "\\a", "\a");
			string = replace_all_distinct(string, "\\b", "\b");
			string.pop_back();
			if (string != "") {
				string = string.substr(1, string.size() - 1);
			}
			return string;
		}
		else {
			return string;
		}
	}

	static std::string& trim(std::string& s) {
		if (s.empty()) return s;

		s.erase(0,s.find_first_not_of(" "));
		s.erase(s.find_last_not_of(" ") + 1);
		return s;
	}

	static std::string& trimOf(std::string& s,std::string sym) {
		if (s.empty()) return s;

		s.erase(0,s.find_first_not_of(sym));
		s.erase(s.find_last_not_of(sym) + 1);
		return s;
	}

	static std::string UTF8ToANSI(std::string str) {
        std::string res;
        wchar_t* src;
        LPSTR lpres;
        int tmp = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, NULL, 0);
        src = new wchar_t[tmp + 5];
        MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, src, tmp);
        tmp = WideCharToMultiByte(CP_ACP, 0, src, -1, NULL, 0, NULL, NULL);
        lpres = new char[tmp + 5];
        WideCharToMultiByte(CP_ACP, 0, src, -1, lpres, tmp, NULL, NULL);
        res = lpres;
        delete[]src;
        delete[]lpres;
        return res;
    }
};

RY_STRUCT_ RyListOerating {
	static RySizeType FindInList(StringList list,std::string fstr) {
		for (RySizeType i = 0; i < list.size(); ++i) {
			if (list.at(i.data()) == fstr) return i;
		}
		return -1;
	}

	static RySizeType FindInListIncomplete(StringList list,std::string fstr) {
		for (RySizeType i = 0; i < list.size(); ++i) {
			if (list.at(i.data()).find(fstr) != Ry_Npos_) return i;
		}
		return -1;
	}
};

RY_STRUCT_ RySysOerating {
	static void error(std::string errorInfo,RySizeType line,std::string code,std::string file = "") {
		HANDLE hdl = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(hdl, FOREGROUND_RED | FOREGROUND_INTENSITY);
		std::cout << "error in line: " << line.data() << std::endl;
		SetConsoleTextAttribute(hdl, FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
		if (file == "") std::cout << "file: " << __FILE__ << std::endl;
		else std::cout << "file: " << file << std::endl;
		std::cout << "code: " << code << std::endl;
		SetConsoleTextAttribute(hdl, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
		std::cout << "error info: " << errorInfo;
		SetConsoleTextAttribute(hdl, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
		std::cout << std::endl;
	}

	static void warning(std::string warningInfo,RySizeType line,std::string code,std::string file = "") {
		HANDLE hdl = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(hdl, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
		std::cout << "warning in line: " << line.data() << std::endl;
		SetConsoleTextAttribute(hdl, FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
		if (file == "") std::cout << "file: " << __FILE__ << std::endl;
		else std::cout << "file: " << file << std::endl;
		std::cout << "code: " << code << std::endl;
		SetConsoleTextAttribute(hdl, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
		std::cout << "error info: " << warningInfo;
		SetConsoleTextAttribute(hdl, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
		std::cout << std::endl;
	}
	
};