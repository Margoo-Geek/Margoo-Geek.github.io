#include "run.h"

int main() {
	HICON hIcon, hIconSm;
	std::wstring cvt = L"icon/window.ico";
	hIcon = (HICON)LoadImage(NULL, cvt.c_str(), IMAGE_ICON, 32, 32, LR_LOADFROMFILE);
	SendMessage(GetConsoleWindow() , WM_SETICON, ICON_BIG, (LPARAM)hIcon);
	hIconSm = (HICON)LoadImage(NULL, cvt.c_str(), IMAGE_ICON, 16, 16, LR_LOADFROMFILE);
	SendMessage(GetConsoleWindow(), WM_SETICON, ICON_SMALL, (LPARAM)hIconSm);
	SetWindowText(GetConsoleWindow(), L"Ryuichi 0.01 beta");
	std::cout << "ryuichi beta 0.01 (2020,5,24) [MSVC v.2019 32 bit] on win32\nInput \"help\" for more information\n\n";
	std::string command;

	while (true) {
		std::cout << "Ryuichi>>>";
		std::getline(std::cin, command);
		if (command.find("help") == 0) {
			std::cout << "\nWelcome to ryuichi Console [v.0.01 beta]\n\nIf this is your first time using Ryuichi, You can go to ryuichi.net.cn to refer to the demo\n\nEnter command on the console like run \"main.ry\" or exit\n\nThis version is a beta version. If there are too many bugs, please forgive me!\n\nIf you find any bug,welcome to call the email:<margoo@ryuichi.net.cn>\n\n";
		}
		else if (command.find("run") == 0) {
			if ((RyStringOerating::SplitString(command," ")).size() >= 2) doFile(RyStringOerating::SplitString(command," ")[1]);
		}
		else if (command.find("exit") == 0) {
			exit(0);
		}
		else if (command.find("version") == 0) {
			std::cout << "\nyuichi beta 0.01 (2020,5,24) [MSVC v.2019 32 bit] on win32\n\n";
		}
	}
	return 0;
}