#pragma once

/*********************************
 * Ryuichi project Beta version 0.01
 * function.h
 * data<2020/5/23>
 * email<margoo@ryuichi.net.cn>
*********************************/
#include "type.h"

#include "ryuichi.h"

const std::string SysFunction[5] = { "print","get","if","while","for" };

struct function {
    std::string              functionName;
    std::vector<std::string> command;
    VarObject                wparam;
    std::string              type;
};

static struct FunctionObject {
    std::vector<function>   buffer;

    void addFunction(std::string name, std::vector<std::string>command, std::string type) {
        function fn;

        fn.functionName = name;
        fn.command      = command;
        fn.type         = type;

        buffer.push_back(fn);
    }

    RySizeType getPos(std::string name) {
        for (RySizeType i = 0; i < buffer.size(); ++i) if (buffer[i.data()].functionName == name) return i;

        return -1;
    }

    bool isFunction(std::string fnName) {
        for (RySizeType i = 0; i < 4; ++i)
            if (fnName == SysFunction[i.data()]) return true;

        if (getPos(fnName) != -1) return true;
        
        return false;
    }
};