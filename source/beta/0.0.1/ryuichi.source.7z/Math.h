#pragma once
#include "ryuichi.h"

#define ATOF(str) atof((str).c_str())  

std::string ToLowerString(std::string str) {  
    transform(str.begin(), str.end(), str.begin(), (int (*)(int))tolower); 
   	return str;
}  

std::string ToUpperString(std::string str) { 
    transform(str.begin(), str.end(), str.begin(), (int (*)(int))toupper); 
   	return str;
}  

void string_Replace(std::string &str,const std::string &fstr,const std::string &rep) {  
    std::string::size_type pos = 0;  
    std::string::size_type a = fstr.length();  
    std::string::size_type b = rep.length();  
    if (b == 0)  
        while ((pos = str.find(fstr, pos)) != std::string::npos) {  
            str.erase(pos, a);  
        }  
    else  
        while ((pos = str.find(fstr, pos)) != std::string::npos) {  
            str.replace(pos, a, rep);  
            pos += b;  
        }  
}  

std::vector<std::string> Split(const std::string str, const std::string pattern, int count = 0) {  
    std::vector<std::string> ret;  
    if (pattern.empty()) return ret;  
    size_t start = 0, index = str.find(pattern, 0);  
    int control = count;  
    while (index != str.npos && (count == 0 || (control--) > 1)) {  
        if (start != index)  
            ret.push_back(str.substr(start, index - start));  
        else  
            ret.push_back(std::string(""));  
        start = index + pattern.length();  
        index = str.find(pattern, start);  
    }  
    if (!str.substr(start).empty())  
        ret.push_back(str.substr(start));  
    else  
        for (int i = 0; i < count - ret.size(); i++)  
            ret.push_back(std::string(""));  
    return ret;  
}  

bool IsNumeric(const std::string& s) {  
    int lk = 0, rk = 0;  
  
    for (std::string::size_type i = 0; i < s.size(); i++) {  
        if (s[i] == '(') {  
            lk++;  
            continue;  
        }  
        if (s[i] == ')') {  
            rk++;  
            continue;  
        }  
        if (s[i] == '.')  
            continue;  
        if (s[i] < '0' || s[i] > '9')  
            return false;  
    }  
    if (lk != rk) return false;  
    return true;  
}  

int sgn(double x)  
{  
    int ret;  
    if (x > 0) ret = 1;  
    if (x < 0) ret = -1;  
    if (x == 0) ret = 0;  
    return ret;  
}  
  
template<typename T>  
std::string toString(const T& t)  
{  
    std::stringstream oss;  
    oss.setf(std::ios::fixed,std::ios::floatfield);  
    oss.precision(14);  
    oss << t;  
    return oss.str();  
}  
  
std::string StrReverse(const std::string &ss)  
{  
    return std::string(ss.rbegin(),ss.rend()); 
}  
  
double Eval(std::string s)  
{  
    double ret = 0;
    char op;  
    s = ToLowerString(s); 
    string_Replace(s," ", "");
    string_Replace(s, "--", "+");
    string_Replace(s, "mod", "%");
    std::string ss("(&-+%\\*/^"); 
    std::string fc[] = {"Abs", "Atn", "Cos", "Exp", "Fix", "Int", "Log", "Rnd", "Sgn", "Sin", "Sqr", "Tan"};  
    for (int i = 0; i < sizeof(fc) / sizeof(fc[0]); i++)  
    {  
        std::vector<std::string> hs = Split(s, ToLowerString(fc[i]));  
        if (hs.size() == 2)
        {  
            if ((IsNumeric(hs[1]) && hs[0].size() < 2) || (hs[0].empty() && hs[1].empty()))  
            {  
                string_Replace(hs[1], "(", "");  
                string_Replace(hs[1], ")", "");  
                switch (i)  
                {  
                case 0:  
                    ret = abs(ATOF(hs[1]));  
                    break;  
                case 1:  
                    ret = atan(ATOF(hs[1]));  
                    break;  
                case 2:  
                    ret = cos(ATOF(hs[1]));  
                    break;  
                case 3:  
                    ret = exp(ATOF(hs[1]));  
                    break;  
                case 4:  
                    ret = floor(ATOF(hs[1]));  
                    break;  
                case 5:  
                    ret = int(ATOF(hs[1]));  
                    break;  
                case 6:  
                    ret = log(ATOF(hs[1]));  
                    break;  
                case 7:  
                    ret = rand() * ATOF(hs[1]);  
                    break;  
                case 8:  
                    ret = sgn(ATOF(hs[1]));  
                    break;  
                case 9:  
                    ret = sin(ATOF(hs[1]));  
                    break;  
                case 10:  
                    ret = sqrt(ATOF(hs[1]));  
                    break;  
                case 11:  
                    ret = tan(ATOF(hs[1]));  
                    break;  
                default:  
                    break;  
                }  
                ret = ATOF(hs[0] + toString(ret));  
                return ret;  
            }  
  
        }  
    }  
    if (IsNumeric(s) || s.empty())  
        ret = ATOF(s);  
    else  
        for (std::string::iterator it = ss.begin(); it != ss.end(); it++) 
        {  
            op = *it;  
            if (s.find(op, 0) != std::string::npos)  
            {  
                std::vector<std::string> fs = Split(StrReverse(s), toString(op), 2);  
                while (! IsNumeric(fs[1].substr(0, 1)) && (op == '-' || op == '+'))  
                {  
                    if (fs[1].find(op, 0) != std::string::npos)  
                    {  
                        std::vector<std::string> ms = Split(fs[1], toString(op), 2);  
                        fs[0] = fs[0] + op + ms[0];  
                        fs[1] = ms[1];  
                    }  
                    else  
                        op = '\0';  
                }  
                fs[0] = StrReverse(fs[0]);  
                fs[1] = StrReverse(fs[1]);  
                std::vector<std::string> ns = Split(fs[0], std::string(")"), 2);  
                switch (op)  
                {  
                case '(':  
                    ret = Eval(fs[1] + toString(Eval(ns[0])) + ns[1]);  
                    return ret;  
                    break;  
                case '&':  
                    ret = ATOF(toString(Eval(fs[1])) + toString(Eval(fs[0])));  
                    break;  
                case '+':  
                    ret = Eval(fs[1]) + Eval(fs[0]);  
                    break;  
                case '-':  
                    ret = Eval(fs[1]) - Eval(fs[0]);  
                    break;  
                case '*':  
                    ret = Eval(fs[1]) * Eval(fs[0]);  
                    break;  
                case '/':  
                    ret = Eval(fs[1]) / Eval(fs[0]);  
                    break;  
                case '\\':  
                    ret = int(Eval(fs[1]) / Eval(fs[0]));  
                    break;  
                case '%':  
                    ret = static_cast<int>(Eval(fs[1])) % static_cast<int>(Eval(fs[0]));  
                    break;  
                case '^':  
                    ret = pow(Eval(fs[1]), Eval(fs[0]));  
                    break;  
                }  
                if (op != '\0')  
                {  
                    return ret;  
                }  
            }  
        }  
    return ret;  
}