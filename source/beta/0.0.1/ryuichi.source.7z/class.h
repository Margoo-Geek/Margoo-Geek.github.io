#pragma once

/*********************************
 * Ryuichi project Beta version 0.01
 * class.h
 * data<2020/5/23>
 * email<margoo@ryuichi.net.cn>
*********************************/

#include "ryuichi.h"
#include "type.h"
#include "function.h"

struct RyClass {
    std::string              className;
    std::vector<VarObject>   wparam;
    FunctionObject function;
};

static struct RyClassObject {
    std::vector<RyClass> cl;

    bool isClass(std::string className) {
        if (className == "string") return true;
        else {
            for (RySizeType i = 0; i < cl.size(); ++i) if (className == cl[i.data()].className) return true;
        }

        return false;
    }

    RySizeType getPos(std::string name) {
		for (RySizeType i = 0; i < cl.size(); ++i) 
            if (name == cl[i.data()].className) return i;
        return -1;
    }
};