#pragma once

/*********************************
 * Ryuichi project Beta version 0.01
 * class.h
 * data<2020/5/23>
 * email<margoo@ryuichi.net.cn>
*********************************/

#include "class.h"
#include "function.h"
#include "type.h"

struct RyGload {
    RyClassObject  Class;
    FunctionObject function;
    VarObject      variable;
};